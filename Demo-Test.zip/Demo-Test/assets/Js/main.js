(function(){
    "use strict";

    // Show review
    $('.review-cta-wrapper .btn-wrapper .btn-blue').click(function(){
        $('.review-wrapper').show();
        $('.review-cta-wrapper').hide();
    });
    $(".review-form .form-control").on("blur input focus", function() {
        var $field = $(this).closest(".form-field");
        if (this.value) {
            $field.addClass("filled");
        } else {
            $field.removeClass("filled");
        }
    });
    $(".review-form .form-control").on("focus", function() {
        var $field = $(this).closest(".form-field");
        if (this) {
            $field.addClass("filled");
        } else {
            $field.removeClass("filled");
        }
    });

    // Review Submit
    $('.review-wrapper button.btn.btn-primary').click(function(ele){
        ele.preventDefault();
        ele.stopPropagation();
        $('.review-wrapper').hide();
        $('.thankyou-wrapper').addClass('show-msg');
        setTimeout(function(){
            $('.thankyou-wrapper').removeClass('show-msg');
            $('.comming-soon').show();
            setTimeout(function(){
                $('.comming-soon').hide();
                $('.improve-wrapper').show();
            }, 3000);
        }, 3000);
    });
    $('.improve-wrapper button.btn.btn-primary').click(function(ele){
        ele.preventDefault();
        ele.stopPropagation();
        $('.improve-wrapper').hide();
        $('.thankyou-wrapper').addClass('show-imp-msg');
    });
})();